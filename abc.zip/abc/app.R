remove(list = ls())
gc(reset = T)

options(shiny.reactlog=TRUE)

library(shinythemes)
library(shinydashboard)
library(shiny)
library(shinyjs)
library(ggplot2)
library(purrr)
library(dplyr)
library(plotly)
library(yaml)
library(DT)
library(jsonlite)
library(RColorBrewer)
library(sqldf)
library(reticulate)
library(slickR)

row <- function(...) {
  tags$div(class="row", ...)
}

col <- function(width, ...) {
  tags$div(class=paste0("span", width), ...)
}

ui <- fluidPage(theme = shinytheme("cerulean"),
                dashboardPage(
                  dashboardHeader(title = "Buzz-Sense"),  
                  dashboardSidebar(
                    img(src = 'large_buzzsense.png', height=150, width=230),
                    sidebarMenu(
                      menuItem("Classifier", tabName = "eda",icon=icon("th")),
                      menuItem("Help", tabName = "hlp",icon=icon("info"))
                    )
                  ),
                  dashboardBody(
                    
                    tags$head(
                      tags$style(HTML("
                                      .main-sidebar {
                                      background-color: lightgrey !important;
                                      }
                                      
                                      /* other links in the sidebarmenu */
                                      .skin-blue .main-sidebar .sidebar .sidebar-menu a{
                                      color: rgb(0,0,0);
                                      }
                                      
                                      /* active selected tab in the sidebarmenu */
                                      .skin-blue .main-sidebar .sidebar .sidebar-menu .active a{
                                      background-color: rgb(0,112,192);
                                      color: rgb(255,255,255);
                                      }
                                      
                                      /* other links in the sidebarmenu when hovered */
                                      .skin-blue .main-sidebar .sidebar .sidebar-menu a:hover{
                                      background-color: rgb(0,112,192);color: rgb(255,255,255);
                                      }
                                      "))
                      ),
                    
                    
                    
                    useShinyjs(),
                    tabItems(
                      tabItem(tabName = "eda",
                              
                              fluidRow(
                                box(title= strong("Input"), width=5, solidHeader = TRUE, 
                                    fileInput("dataset_eda", "Choose CSV File"), 
                                    column(12, sliderInput("samp", "Select Sample Size (%age):",  min = 1, max = 100,  value = 5, step = 1)),
                                    column(12, br()),
                                    column(6, selectInput("mtext","Text variable", choices=c())), 
                                    column(6, selectInput("mevent","Target variable",choices=c())),
                                    column(12, br()),
                                    actionButton("process1", "Confirm", icon = icon("envelope"))
                                    
                                ),
                                
                                box(title= strong("Word Cloud"), width=7, solidHeader = TRUE, 
                                    column(4, selectInput("mfilt","Filter variable", choices=c())), 
                                    column(4, selectInput("filt.val","Filter value",choices=c())),
                                    column(2, offset=1, actionButton("process2", "Show", icon = icon("envelope"))),
                                    plotOutput("word_plot")
                                    
                                )
                              ),
                              
                              fluidRow(
                                box(title= strong("Sample View") , width=12,  
                                    dataTableOutput("mytable1.sd"), solidHeader = T)
                              ),
                              
                              fluidRow(
                                box(title= strong("Algorithm"), width = 12, solidHeader = T,
                                    column(2,selectInput("classify","Classifier",choices=list("FastText"=1, "Random Forest"=2, "Linear SVC"=3, "Logistic Regression"=4), 
                                                         selected = 1)),
                                    conditionalPanel(condition = "input.classify==1",
                                                     column(10,  h3(strong("Facebook FastText")),
                                                            p((strong("FastText combines some of the most successful concepts introduced by the natural language processing and machine learning communities in the last few decades. These include representing sentences with bag of words and bag of n-grams, as well as using subword information, and sharing information across classes through a hidden representation. We also employ a hierachical softmax that takes advantage of the unbalanced distribution of the classes to speed up computation. These different concepts are being used for two different tasks: efficient text classification and learning word vector representations.")))
                                                     ),
                                                     column(12, h4(strong("Hyper Parameters"))),
                                                     column(12,
                                                            column(3, numericInput("ft.epoch", "Epochs:", value = 100, min = 50, max = 500, step = 50)),
                                                            column(3, numericInput("ft.wordNgrams", "Word-Grams:", value = 2, min = 1, max = 5, step = 1)),
                                                            column(3, numericInput("ft.dim", "Dimensions:", value = 100, min = 50, max = 500, step = 50)),
                                                            column(3, numericInput("ft.lr", "Learning Rate:", value = 0.7, min = 0.1, max = 1.0, step = 0.05)),
                                                            column(3, numericInput("ft.ws", "Window Size:", value = 2, min = 1, max = 5, step = 1))
                                                     )
                                                     
                                                     
                                    ),
                                    
                                    conditionalPanel(condition = "input.classify==2",
                                                     column(10,  h3(strong("Random Forest")),
                                                            p((strong("Random Forest is a flexible, easy to use machine learning algorithm that produces, even without hyper-parameter tuning, a great result most of the time. It is also one of the most used algorithms, because it's simplicity and the fact that it can be used for both classification and regression tasks. Random Forests are trained via the bagging method. Bagging or Bootstrap Aggregating, consists of randomly sampling subsets of the training data, fitting a model to these smaller data sets, and aggregating the predictions.")))
                                                     ),
                                                     column(12, h4(strong("Hyper Parameters"))),
                                                     column(12,
                                                            column(3, numericInput("rf.n_estimators", "# Estimators:", value = 200, min = 50, max = 500, step = 50)),
                                                            column(3, numericInput("rf.max_depth ", "Max Depth:", value = 30, min = 5, max = 50, step = 5)),
                                                            column(3, selectInput("rf.criterion ", "Criterion:", choices = c("gini","entropy"))),
                                                            column(3, selectInput("rf.max_features ", "Max. Features:",  choices = c("sqrt","log2")))
                                                     )
                                                     
                                                     
                                    ),
                                    
                                    conditionalPanel(condition = "input.classify==3",
                                                     column(10,  h3(strong("Linear SVC")),
                                                            p((strong("Support Vector Machine(SVM) is a supervised machine learning algorithm which can be used for both classification or regression challenges. However, it is mostly used in classification problems. In this algorithm, we plot each data item as a point in n-dimensional space (where n is number of features) with the value of each feature being the value of a particular coordinate. Then, we perform classification by finding the hyper-plane that differentiate the classes very well.")))
                                                     ),
                                                     column(12, h4(strong("Hyper Parameters"))),
                                                     column(12,
                                                            column(3, selectInput("lsvc.penalty ", "Penalty:", choices = c("l2","l1"))),
                                                            column(3, numericInput("lsvc.c ", "C (Penalty):", value = 1.0, min = 0.1, max = 20.0, step = 0.1)),
                                                            column(3, selectInput("lsvc.loss ", "Loss:", choices = c("squared_hinge","hinge"))),
                                                            column(3, numericInput("lsvc.max_iter", "Max Iterations:", value = 1000, min = 100, max = 10000, step = 100))
                                                     )
                                                     
                                                     
                                    ),
                                    
                                    conditionalPanel(condition = "input.classify==4",
                                                     column(10,  h3(strong("Logistic Regression")),
                                                            p((strong("Logistic regression is a statistical machine learning algorithm that classifies the data by considering outcome variables on extreme ends and tries makes a logarithmic line that distinguishes between them.")))
                                                     ),
                                                     column(12, h4(strong("Hyper Parameters"))),
                                                     column(12,
                                                            column(3, selectInput("lr.multi_class ", "Multi-Class:", choices = c("auto","multinomial"))),
                                                            column(3, selectInput("lr.solver ", "Solver:", choices = c("lbfgs","sag","saga","newton-cg"))),
                                                            column(3, selectInput("lr.penalty ", "Penalty:", choices = c("l2","l1"))),
                                                            column(3, numericInput("lr.c ", "C (Penalty):", value = 1.0, min = 0.1, max = 20.0, step = 0.1)),
                                                            column(3, numericInput("lr.max_iter", "Max Iterations:", value = 100, min = 50, max = 500, step = 50))
                                                     )
                                    ),
                                    column(12, br()),
                                    column(2, actionButton("process3", "Train", icon = icon("envelope")))
                                )
                              ),
                              
                              fluidRow(
                                box(title= strong("Evaluation"), width = 12, solidHeader = T,
                                    column(12, h4(strong("Train:"))),
                                    infoBoxOutput("train_acc", width = 3), infoBoxOutput("train_rec", width = 3),
                                    infoBoxOutput("train_pre", width = 3), infoBoxOutput("train_f1", width = 3),
                                    
                                    column(12, br()),
                                    
                                    column(12, h4(strong("Test:"))),
                                    infoBoxOutput("test_acc1", width = 3), infoBoxOutput("test_rec", width = 3),
                                    infoBoxOutput("test_pre", width = 3), infoBoxOutput("test_f1", width = 3)
                                )
                              )
                              
                      ),
                      
                      
                      tabItem(tabName = "hlp",
                              fluidRow(
                                box(
                                  title = strong("Accuracy:"), solidHeader = TRUE, width = 12,
                                  strong("Accuracy is the most intuitive performance measure and it is simply a ratio of correctly predicted observation to the total observations. One may think that, if we have high accuracy then our model is best. Yes, accuracy is a great measure but only when you have symmetric datasets where values of false positive and false negatives are almost same. Therefore, you have to look at other parameters to evaluate the performance of your model."),
                                  br(), br(),
                                  strong("Accuracy = TP+TN/TP+FP+FN+TN")
                                ),
                                
                                box(
                                  title = strong("Recall:"), solidHeader = TRUE, width = 12,
                                  strong("Recall is the ratio of correctly predicted positive observations to the all observations in actual class."),
                                  br(), br(),
                                  strong("Recall = TP/TP+FN")
                                ),
                                
                                box(
                                  title = strong("Precision:"), solidHeader = TRUE, width = 12,
                                  strong("Precision is the ratio of correctly predicted positive observations to the total predicted positive observations. High precision relates to the low false positive rate."),
                                  br(), br(),
                                  strong("Precision = TP/TP+FP")
                                ),
                                
                                box(
                                  title = strong("F1-score:"), solidHeader = TRUE, width = 12,
                                  strong("F1 Score is the weighted average of Precision and Recall. Therefore, this score takes both false positives and false negatives into account. Intuitively it is not as easy to understand as accuracy, but F1 is usually more useful than accuracy, especially if you have an uneven class distribution. Accuracy works best if false positives and false negatives have similar cost. If the cost of false positives and false negatives are very different, it's better to look at both Precision and Recall. We can add aa weighting to account for the higher consequence of eigher false positives or negatives (second slider)"),
                                  br(), br(),
                                  strong("F1 Score = 2*(Recall * Precision) / (Recall + Precision)"),
                                  br(), br(),
                                  img(src='f1-score definition.png', align = "center")
                                )
                              )
                      )
                      
                      
                    ))))



server <- function(session,input, output) {
  set.seed(42)
  
  
  inFile_eda <-reactive({
    
    if (is.null(input$dataset_eda)){
      return(NULL)
    } else {
      return(read.csv(input$dataset_eda$datapath, header = TRUE, na.strings =c("","NA", stringsAsFactors = F)))
    }
    
  })
  
  
  p_eda <- reactiveValues(raw_file_eda=NULL, samp_file_eda=NULL, text_col=NULL, event_col=NULL, df1=NULL)
  
  set.seed(42)
  observeEvent(inFile_eda(), {
    
    p_eda$raw_file_eda <- inFile_eda()
    
    choice1 <- c("(None)", names(p_eda$raw_file_eda))
    
    updateSelectInput(session, "mtext", choices = choice1)
    updateSelectInput(session, "mevent", choices = choice1)
    
    showModal(modalDialog(HTML(paste0("Pre-Processing done.","<br>","Data has ",
                                      class(choice1)," rows and ", ncol(p_eda$raw_file_eda)," columns."))
                          ,easyClose =  T, footer = modalButton("OK")))
    
  })
  
  
  
  observeEvent(input$process1, {
    
    set.seed(42)
    p_eda$samp_file_eda <- sample_frac(p_eda$raw_file_eda, input$samp/100)
    
    choice2 <- c("(None)", colnames(p_eda$samp_file_eda))
    updateSelectInput(session, "mfilt", choices = choice2)
    
    if(!is.null(input$mtext) && !is.null(input$mevent)) {
      
      if(input$mtext !="(None)") {
        p_eda$text_col <- p_eda$samp_file_eda[[input$mtext]]
        names(p_eda$text_col) <- "Reviews"
      } else {
        p_eda$text_col <- NULL
      }
      
      if(input$mevent !="(None)") {
        p_eda$event_col <- p_eda$samp_file_eda[[input$mevent]]
        names(p_eda$event_col) <- "Sentiment"
      } else {
        p_eda$event_col <- NULL
      }
      
      if(!is.null(p_eda$text_col) && !is.null(p_eda$event_col)) {
        p_eda$df1 <- cbind(p_eda$text_col, p_eda$event_col)
      } else {
        p_eda$df1 <- NULL
      }
    }
    
  })
  
  
  
  observeEvent(input$mfilt, {
    
    if(input$mfilt !="(None)") {
      updateSelectInput(session, "filt.val", choices = unique(p_eda$samp_file_eda[, input$mfilt]))
    } else {
      updateSelectInput(session, "filt.val", choices = c())
    }
    
  })
  
  
  
  
  output$mytable1.sd <- renderTable({
    
    if(!is.null(p_eda$raw_file_eda)) {
      if (nrow(p_eda$raw_file_eda) >= 50) {
        
        return(head(p_eda$raw_file_eda, 50))
        
      } else {
        
        return(p_eda$raw_file_eda)
        
      }}
  })
  
  
  # observeEvent(p_eda$raw_file_eda, {
  #   
  #   if(!is.null(inFile_eda())){
  #       session$reload()
  #       
  #   }
  # 
  #       
  # })
  
  
  # use_python("/opt/app/anaconda3/bin/python")
  # source_python("/spare/share/nbroot/public/43854702/R_deploy/Anomaly App/PyMapper.py", envir = globalenv())
  
  
  output$train_acc <- renderInfoBox({
    infoBox(
      title = strong("Accuracy:"), paste(p_eda$y),
      icon = icon("crosshairs"), color = "light-blue", fill=T
    )
  })
  
  output$train_rec <- renderInfoBox({
    infoBox(
      title = strong("Recall:"), paste(p_eda$y),
      icon = icon("phabricator"), color = "light-blue", fill=T
    )
  })
  
  output$train_pre <- renderInfoBox({
    infoBox(
      title = strong("Precision:"), paste(p_eda$y),
      icon = icon("bullseye"), color = "light-blue", fill=T
    )
  })
  
  output$train_f1 <- renderInfoBox({
    infoBox(
      title = strong("F1-Score:"), paste(p_eda$y),
      icon = icon("flag-checkered"), color = "light-blue", fill=T
    )
  })
  
  
  
  output$test_acc1 <- renderInfoBox({
    infoBox(
      title = strong("Accuracy:"), paste(p_eda$y),
      icon = icon("crosshairs"), color = "green", fill=T
    )
  })
  
  
  output$test_rec <- renderInfoBox({
    infoBox(
      title = strong("Recall:"), paste(p_eda$y),
      icon = icon("phabricator"), color = "green", fill=T
    )
  })
  
  output$test_pre <- renderInfoBox({
    infoBox(
      title = strong("Precision:"), paste(p_eda$y),
      icon = icon("bullseye"), color = "green", fill=T
    )
  })
  
  output$test_f1 <- renderInfoBox({
    infoBox(
      title = strong("F1-Score:"), paste(p_eda$y),
      icon = icon("flag-checkered"), color = "green", fill=T
    )
  })
  
  
}

shinyApp(ui, server)
