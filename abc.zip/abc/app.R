remove(list = ls())
gc(reset = T)

options(shiny.reactlog=TRUE)

library(shinythemes)
library(shinydashboard)
library(shiny)
library(shinyjs)
library(ggplot2)
library(purrr)
library(dplyr)
library(plotly)
library(yaml)
library(DT)
library(jsonlite)
library(RColorBrewer)
library(sqldf)
library(reticulate)
library(slickR)

row <- function(...) {
  tags$div(class="row", ...)
}

col <- function(width, ...) {
  tags$div(class=paste0("span", width), ...)
}

ui <- fluidPage(theme = shinytheme("cerulean"),
  dashboardPage(
  dashboardHeader(title = "Buzz-Sense"),  
  dashboardSidebar(
    img(src = 'large_buzzsense.png', height=150, width=230),
    sidebarMenu(
      menuItem("Classifier", tabName = "eda",icon=icon("th")),
      menuItem("Help", tabName = "hlp",icon=icon("info"))
    )
  ),
  dashboardBody(
    
    tags$head(
      tags$style(HTML("
          .main-sidebar {
            background-color: lightgrey !important;
          }

        /* other links in the sidebarmenu */
          .skin-blue .main-sidebar .sidebar .sidebar-menu a{
          color: rgb(0,0,0);
          }

        /* active selected tab in the sidebarmenu */
            .skin-blue .main-sidebar .sidebar .sidebar-menu .active a{
          background-color: rgb(0,112,192);
          color: rgb(255,255,255);
            }

        /* other links in the sidebarmenu when hovered */
          .skin-blue .main-sidebar .sidebar .sidebar-menu a:hover{
          background-color: rgb(0,112,192);color: rgb(255,255,255);
          }
        "))
    ),
    
    
    
    useShinyjs(),
    tabItems(
      tabItem(tabName = "eda",
              fluidRow(
                box(title= strong("Input"), width=4, solidHeader = TRUE, 
                    fileInput("dataset_eda", "Choose CSV File"), 
                    column(12, sliderInput("samp", "Select Sample Size (%age):",  min = 1, max = 100,  value = 5, step = 1)),
                    column(6, selectInput("mtext","Text variable", choices=c())), 
                    column(6, selectInput("mevent","Target variable",choices=c())),
                    actionButton("process", "Submit", icon = icon("envelope"))
                    
                ),
                
                # infoBoxOutput("testcol"),
                
                box(title= strong("Algorithm"), width = 8, solidHeader = T,
                column(2,selectInput("classify","Classifier",choices=list("FastText"=1, "Random Forest"=2, "Linear SVC"=3, "Logistic Regression"=4), 
                                     selected = 1)),
                conditionalPanel(condition = "input.classify==1",
                                 column(10,  h3(strong("Facebook FastText")),
                                        p((strong("ABC")))
                                        ),
                                 column(12, h4(strong("Hyper Parameters"))),
                                 column(12,
                                        column(3, numericInput("ft.epoch", "Epochs:", value = 100, min = 50, max = 500, step = 50)),
                                        column(3, numericInput("ft.wordNgrams", "Word-Grams:", value = 2, min = 1, max = 5, step = 1)),
                                        column(3, numericInput("ft.dim", "Dimensions:", value = 100, min = 50, max = 500, step = 50)),
                                        column(3, numericInput("ft.lr", "Learning Rate:", value = 0.7, min = 0.1, max = 1.0, step = 0.05)),
                                        column(3, numericInput("ft.ws", "Window Size:", value = 2, min = 1, max = 5, step = 1))
                                        )
                                 
                                 
                                 ),
                
                conditionalPanel(condition = "input.classify==2",
                                 column(10,  h3(strong("Random Forest")),
                                        p((strong("ABC")))
                                        ),
                                 column(12, h4(strong("Hyper Parameters"))),
                                 column(12,
                                        column(3, numericInput("rf.n_estimators", "# Estimators:", value = 200, min = 50, max = 500, step = 50)),
                                        column(3, numericInput("rf.max_depth ", "Max Depth:", value = 30, min = 5, max = 50, step = 5)),
                                        column(3, selectInput("rf.criterion ", "Criterion:", choices = c("gini","entropy"))),
                                        column(3, selectInput("rf.max_features ", "Max. Features:",  choices = c("sqrt","log2")))
                                        )
                                 
                                 
                                ),
                
                conditionalPanel(condition = "input.classify==3",
                                 column(10,  h3(strong("Linear SVC")),
                                        p((strong("ABC")))
                                 ),
                                 column(12, h4(strong("Hyper Parameters"))),
                                 column(12,
                                        column(3, selectInput("lsvc.penalty ", "Penalty:", choices = c("l2","l1"))),
                                        column(3, numericInput("lsvc.c ", "C (Penalty):", value = 1.0, min = 0.1, max = 20.0, step = 0.1)),
                                        column(3, selectInput("lsvc.loss ", "Loss:", choices = c("squared_hinge","hinge"))),
                                        column(3, numericInput("lsvc.max_iter", "Max Iterations:", value = 1000, min = 100, max = 10000, step = 100))
                                        )
                                 
                                 
                                ),
                
                conditionalPanel(condition = "input.classify==4",
                                 column(10,  h3(strong("Logistic Regression")),
                                        p((strong("ABC")))
                                 ),
                                 column(12, h4(strong("Hyper Parameters"))),
                                 column(12,
                                        column(3, selectInput("lr.multi_class ", "Multi-Class:", choices = c("auto","multinomial"))),
                                        column(3, selectInput("lr.solver ", "Solver:", choices = c("lbfgs","sag","saga","newton-cg"))),
                                        column(3, selectInput("lr.penalty ", "Penalty:", choices = c("l2","l1"))),
                                        column(3, numericInput("lr.c ", "C (Penalty):", value = 1.0, min = 0.1, max = 20.0, step = 0.1)),
                                        column(3, numericInput("lr.max_iter", "Max Iterations:", value = 100, min = 50, max = 500, step = 50))
                                        )
                                 
                                 
                                )
                
                
                
                )
                
                
              ),
              fluidRow(
                box(title= strong("Sample View") , width=6,tableOutput("mytable1.sd"),
                    style = "height:480px; overflow-y: scroll;overflow-x: scroll;", solidHeader = T),
                
                box(title= strong("Evaluation"), width = 6, solidHeader = T,
                       column(6, h4(strong("Train:"))),  column(6, h4(strong("Test:"))),
                       
                       infoBoxOutput("acc_tr", width = 6), infoBoxOutput("acc_ts", width = 6),
                       infoBoxOutput("rec_tr", width = 6), infoBoxOutput("rec_ts", width = 6),
                       infoBoxOutput("pre_tr", width = 6), infoBoxOutput("pre_ts", width = 6),
                       infoBoxOutput("f1_tr", width = 6), infoBoxOutput("f1_ts", width = 6))
              )
              
      ),
      
      
      tabItem(tabName = "hlp",
              fluidRow(
                box(
                  title = strong("Accuracy:"), solidHeader = TRUE, width = 12,
                  strong("Accuracy is the most intuitive performance measure and it is simply a ratio of correctly predicted observation to the total observations. One may think that, if we have high accuracy then our model is best. Yes, accuracy is a great measure but only when you have symmetric datasets where values of false positive and false negatives are almost same. Therefore, you have to look at other parameters to evaluate the performance of your model."),
                  br(), br(),
                  strong("Accuracy = TP+TN/TP+FP+FN+TN")
                ),
                
                box(
                  title = strong("Recall:"), solidHeader = TRUE, width = 12,
                  strong("Recall is the ratio of correctly predicted positive observations to the all observations in actual class."),
                  br(), br(),
                  strong("Recall = TP/TP+FN")
                ),
                
                box(
                  title = strong("Precision:"), solidHeader = TRUE, width = 12,
                  strong("Precision is the ratio of correctly predicted positive observations to the total predicted positive observations. High precision relates to the low false positive rate."),
                  br(), br(),
                  strong("Precision = TP/TP+FP")
                ),
                
                box(
                  title = strong("F1-score:"), solidHeader = TRUE, width = 12,
                  strong("F1 Score is the weighted average of Precision and Recall. Therefore, this score takes both false positives and false negatives into account. Intuitively it is not as easy to understand as accuracy, but F1 is usually more useful than accuracy, especially if you have an uneven class distribution. Accuracy works best if false positives and false negatives have similar cost. If the cost of false positives and false negatives are very different, it's better to look at both Precision and Recall. We can add aa weighting to account for the higher consequence of eigher false positives or negatives (second slider)"),
                  br(), br(),
                  strong("F1 Score = 2*(Recall * Precision) / (Recall + Precision)"),
                  br(), br(),
                  img(src='f1-score definition.png', align = "center")
                )
              )
      )
      
      
  ))))



server <- function(session,input, output) {
  set.seed(42)
  
  # output$guide <- renderSlickR({
  #   imgs <- sort(list.files("/spare/share/nbroot/public/43854702/R_deploy/Anomaly App/www/help", pattern=".PNG", full.names = TRUE), decreasing = FALSE)
  #   slickR(obj = imgs,slideId = 'ex1', height = "800px", width='80%')
  # 
  # })
  
  inFile_eda <-reactive({
    inFile_eda <- input$dataset_eda
    if (is.null(inFile_eda))
      return(NULL)
    read.csv(inFile_eda$datapath, header = TRUE, na.strings =c("","NA"), stringsAsFactors = F)
    
  })
  
  
  p_eda <- reactiveValues()
  
  set.seed(42)
  
  
  
  observe({
    
    p_eda$raw_file_eda <- inFile_eda()
    
    p_eda$cols<- colnames(p_eda$raw_file_eda)
    
    updateSelectInput(session, "mtext", choices = p_eda$cols)
    updateSelectInput(session, "mevent", choices = p_eda$cols)
    
  })
  
  
  
  
  output$mytable1.sd <- renderTable({
    
    if(!is.null(p_eda$raw_file_eda)) {
    if (nrow(p_eda$raw_file_eda) >= 50) {
      
     return(head(p_eda$raw_file_eda, 50))
      
    } else {
      
      return(p_eda$raw_file_eda)
      
    }}
  })
  
  
  # observeEvent(p_eda$raw_file_eda, {
  #   
  #   if(!is.null(inFile_eda())){
  #       session$reload()
  #       
  #   }
  # 
  #       
  # })
  
  
  # use_python("/opt/app/anaconda3/bin/python")
  # source_python("/spare/share/nbroot/public/43854702/R_deploy/Anomaly App/PyMapper.py", envir = globalenv())
  
  
  observeEvent(input$drop_data, {
    
  })
  
  
  
  chk_list <- reactiveValues()
  
  
  
  
  output$acc_tr <- renderInfoBox({
    infoBox(
      title = strong("Accuracy:"), paste(p_eda$y),
      icon = shiny::icon("crosshairs"), color = "light-blue", fill=T
    )
  })
  
  output$rec_tr <- renderInfoBox({
    infoBox(
      title = strong("Recall:"), paste(p_eda$y),
      icon = shiny::icon("phabricator"), color = "light-blue", fill=T
    )
  })
  
  output$pre_tr <- renderInfoBox({
    infoBox(
      title = strong("Precision:"), paste(p_eda$y),
      icon = shiny::icon("bullseye"), color = "light-blue", fill=T
    )
  })
  
  output$f1_tr <- renderInfoBox({
    infoBox(
      title = strong("F1-Score:"), paste(p_eda$y),
      icon = shiny::icon("flag-checkered"), color = "light-blue", fill=T
    )
  })
  
  
  
  output$acc_ts <- renderInfoBox({
    infoBox(
      title = strong("Accuracy:"), paste(p_eda$y),
      icon = shiny::icon("crosshairs"), color = "green", fill=T
    )
  })
  
  output$rec_ts <- renderInfoBox({
    infoBox(
      title = strong("Recall:"), paste(p_eda$y),
      icon = shiny::icon("phabricator"), color = "green", fill=T
    )
  })
  
  output$pre_ts <- renderInfoBox({
    infoBox(
      title = strong("Precision:"), paste(p_eda$y),
      icon = shiny::icon("bullseye"), color = "green", fill=T
    )
  })
  
  output$f1_ts <- renderInfoBox({
    infoBox(
      title = strong("F1-Score:"), paste(p_eda$y),
      icon = shiny::icon("flag-checkered"), color = "green", fill=T
    )
  })
  
  
}

shinyApp(ui, server)
